#ifndef ECE642RTLE_STUDENT_NOID_STUDENT_TURTLE_H_
#define ECE642RTLE_STUDENT_NOID_STUDENT_TURTLE_H_

#include "student.h"
#include "properties.h"

typedef enum TurtleHandRule {
  kLeftHand = 0,
  kRightHand,
} TurtleHandRule;

#endif // ECE642RTLE_STUDENT_NOID_STUDENT_TURTLE_H_
