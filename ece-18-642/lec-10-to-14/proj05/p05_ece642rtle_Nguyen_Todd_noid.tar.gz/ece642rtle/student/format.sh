#!/bin/bash
astyle --options=astylerc.ini *.cpp *.h
 
